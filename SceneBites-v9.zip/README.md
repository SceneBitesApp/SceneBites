# SceneBites v9

100-title catalog with two subtitle-supported estimated cues: Home Alone (00:49:33 cheese pizza line) and Luca (00:39:09 eating sounds after trenette al pesto served). No visually verified first-bite times.

To activate alerts for a subtitle-supported estimate, open the title and tap **Save my timestamp**. This is intentionally opt-in. Existing locally saved user times are preserved using the v7 storage key.

Replace `index.html` in the root of your GitHub Pages repository. Browser alerts only work with the page open and active.
